if (document.readyState !== 'loading') {
	lnAdminInit();
} else {
	document.addEventListener('DOMContentLoaded', function () {
		lnAdminInit();
	});
}

function lnAdminInit() {

}