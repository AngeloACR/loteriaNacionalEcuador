const db = require("../database").init();

module.exports.db = db;